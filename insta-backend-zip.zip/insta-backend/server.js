const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');
require('dotenv').config();

const app = express();

// Connect Database
connectDB();

// Init Middleware
app.use(express.json());
app.use(cors());
app.get('/api/test', (req, res) => {
  res.json({ success: true, message: 'API is working!' });
});
// Define Routes (Make sure these files export an Express router)
app.use('/api/auth', require('./routes/auth'));
app.use('/api/posts', require('./routes/posts'));

// Set the PORT
const PORT = 5001; // Change to 5001 or another free port

// Start the server
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
